# 新e動

###### tags: `專案交接`

## 目前版本
- App Store: `1.15.0`
- 版本號規則: `x.zz.yy`
    - `x.zz` : APP 版號
    - `yy`   : WEB 版號 (放入新網頁時PROD為0，UAT、DEV為00，進行熱更新後調整)
        - 詳情請參考熱更新部分
## 版控
- 上線: `master`、`develop`
- 開發: `feature/dev-phase2`
- CICD打包: `rc/dev-phase2-rc`
- 新需求:
    - `feature/phase2/dev-testDynamicIcon`: 動態更換Icon Sample
        - 郵局評估中
- 開發紀錄
    - `feature/phase1/dev-addFidoSDK1.2.9`: 更換Fido SDK 1.2.9
        - 因為郵局中台無法同步更新，所以換回1.2.6
    - `feature/phase1/dev-verifyCertificate`: 驗證憑證Sample
        - 因爲郵局中台憑證掛錯，目前郵局未實做驗憑證
- 未使用： (想刪除可以跟android同步)
    - `feature/dev-phase1`
    - `rc/dev-phase1-rc`
    - `rc/uat-phase1-rc`
    - `rc/uat-phase2-rc`
## 交版方式
- 提供郵局測試
    - 包版
    1. 會將已打包的網頁發送至MM群組`新e動郵局Native戰隊-mpost5`，請下載此壓縮檔
    2. 切換至開發分支`feature/dev-phase2`
    3. 解壓縮檔案後，更換`mPost/mPost/Resource/post-m-post-5-www`路徑下的WEB
        ![](RCWEB.png)
    4. 檢查 `post-m-post-5-www`資料夾下的version.txt中的版本，是否與此次發版版本一致
        ![](RCVersion.png)
    5. 修改UAT、DEV版本號 
    ![](RCVersion2.png)
        - mPost_UAT、NotificationService_UAT、widget_UAT
        - mPost_DEV、NotificationService_DEV、widget_DEV
    6. push 至 `feature/dev-phase2` 並 merge 至 `rc/dev-phase2-rc`
    7. 使用Postman 發送 Webhook
        - Method: Post
        - URl: http://10.2.3.169:8080/generic-webhook-trigger/invoke?token=post-m-post-5-iphone
        - Param:
            - `token`: `post-m-post-5-iphone`
        - Headers
            - `Content-Type`: `application/json`
            - `User-Agent`: `GitLab/14.3.2`
            - `X-Gitlab-Event`: `Push Hook`
            - `X-Gitlab-Token`: `post-m-post-5-iphone`
        - Body: 請至 gitlab 上複製
            1. post-m-post-5-iphone -> Setting -> Webhooks
            2. 下滑查看Project Hooks中，選擇對應設定的 Edit，進入編輯頁
            3. 下滑查看Recent Deliveries，找到對應的事件點擊 View details
            4. 複製 `Request body`貼上至Postman
    8. 至jenkins 確認是否開始包版  post-m-post-5-phone -> post-m-post-5-iphone-dev-phase2-rc
    9. 壓縮原始碼放到Synolgy Drive，命名依照先前格式
    10. 至MM`新e動郵局`發送訊息通知PM，格式可參考先前訊息
    11. IPA 包好上傳至App Services -> `iOS-DEV-Phase2`，而後至MM`新e動郵局`發送訊息通知PM
- 上架
    - 由郵局修改PROD版號，PM會通知使用哪版UAT上架和修改後版號

## 套件
- HybridSDK
    - 現有的Delegate
        1. AppDelegate目前使用Delegate:
            - `MTKHybridUtilDelegate` - 共用方法
            - onVerifyCertificate - 驗憑證 (請見備註)
            - onSetStorageData / onGetStorageData - 存取UserDefault (有加密)
        2. 首頁(HomePageVC)目前使用Delegate:
            - `MTKHybridWebUserControllerDelegate` - 基礎方法
                - `onPostMessage` - 新e動自定義方法
                    - fidoInterfaceManager - Fido 有關的方法由此處理
                    - mPostInterfaceManager - 其他自定義方法
                - `onResultMessage` - 由原生發起Request後回覆的Response(未使用)
            - `aesCryptoKeyDelegate` 產生AES KEY
                - 帶入值 keySource相同會產生相同的key
            - `rsaCryptoKeyDelegate` - rsa 加密
            - `appValueDelegate` - 存/取記憶體的值
            - `permissionDelegate` - 確認、詢問權限
                - 因要與android同步，有些權限是android的，這邊依據情形回傳
            - `albumPhotoDelegate` - 相簿
            - `shareContentDelegate` - 分享
            - `barcodeScannerDelegate` - barcode掃描
                - 傳過來的x、ｙ、w、h 為定義可掃描區域
            - `decodeBarcodeDelegate` - 解析barcode
                - 使用 Vision 解析
                - 與android 訂的規則 -> 先解析參數指定的codeType若無解析成功，則回傳可解析的type
            - `flashlightDelegate` - 手電筒
            - `brightnessDelegate` - 螢幕亮度
            - `phoneDelegate` - 電話
            - `webDelegate` - 開啟其他網頁
                - 參數`data`有值，使用`post`開啟webview
            - `contactsInfoDelegate` - 聯絡人
                - 目前定義取`手機`、`姓`、`名`欄位
            - `geoLocationDelegate` - 地理位置
            - `sendWebApiDelegate`
                - 參數`timeout`為nil，使用預設`180`
                - 參數`timeout`目前使用於app啟動時的推播電文
            - `screenRecordingDelegate` - 螢幕錄影
                - 允許螢幕的狀態下，才會由原生發起`notifyScreenRecording` interface
        3. WebViewFrameVC 目前使用Delegate:
            - `webDelegate` - 開啟其他網頁
                - 只實作外開
    - 新增自定義interface
        - Web to Native
            1. 於 MPostInterfaceWebRequestName 新增 name
            2. 於 Data/Interface/Request or Response 的資料夾新增 Request或Response，若有enum請於 Data/Element下建立
            3. 於 MPostWebDelegate 新增 interface
            4. 於 MPostInterfaceManager的filterFidoRequestName func 開始建立處理資料的流程
            5. 回到首頁繼承MPostWebDelegate的extension下實作interface
- AuthSDKFramework
    - version: 1.2.6
    - FIDO，用於快速登入
    - 主要呼叫方法：
        - `getSupportedAuthenticator`: 取得所註冊狀態/所支援的驗證器資料
        - `doRegistration`: 註冊FIDO UAF
        - `syncRegData`: 進行 server authentication，完成註冊，並將server回傳的resp存入sdk內: 
        - `doAuthentication`: 驗證FIDO UAF
        - `doDeregistration`: 根據註冊的使用者名稱username來註銷所有FIDO UAF註冊資料
    - 包含功能: 
        - 圖形解鎖
        - 生物辨識
        - 多國語系: `setupLanguage(languageCode:)`
- iPost
    - 行為軌跡
    - 分環境(iPostPROD、iPostUAT、iPostDEV)
    - 用 uuid 分辨使用者
    ![](PackegeiPost.png)
- PartialUpdateSDK
    - 熱更新(未使用)
    - 呼叫時機：
        - APP 開啟時
        - `updateWebFile` interfce
    - `PartialUpdateManager`
        - 初始化
            ```Swift
            public convenience init(defaultWebFolder: String,
                                    partialUpdateInitFinishCompletionHandler: @escaping PartialUpdateInitFinish) {
                self.init()
                self.partialUpdateInitFinishCompletionHandler = partialUpdateInitFinishCompletionHandler
                /// PartialUpdateSDK 初始化
                self.updateManager =  PartialUpdateObject(
                                        domain: "",
                                        publicKey: "",
                                        defaultKey: "",
                                        updateOriginalVer: "",
                                        appCurrentVer: "",
                                        appId: "");

                self.updateManager?.delegate
                /// 帶入本地網頁路徑
                self.updateManager?.deliverWebFolderName(defaultWebFolder)
            }
            ```
        - 在初始化後，APP 開啟時會比對版號，若APP版號(`x.zz`)與UserDefault(MPostConstant.UserDefaultKeyStr.UPDATE_VERSION)不相符，呼叫以下方法
            ```Swift
            /// 更新APP版號時，進行 Rest
            func restPartialUpdate() {
                partialUpdateManager?.resetOriginalVersion { [weak self] isSuccess, pathStr, htmlName, errCode, errShowMsg in
                    guard let strongSelf else {
                        return
                    }
                    // 成功
                    if isSuccess || errCode == PartialUpdateError.ERROR_DELETE_FILE.rawValue {
                        strongSelf.partialUpdateUrl = strongSelf.composePartialUpdateUrl(pathStr: pathStr, htmlName: htmlName)
                
                        UserDefaultUtil.save(key: MPostConstant.UserDefaultKeyStr.UPDATE_VERSION.rawValue, saveObj: Bundle.main.bVersion)
                
                        #if mPost_DEV
                            strongSelf.removeBackgroundView()
                            strongSelf.showWebURLAlert()
                        #else
                            strongSelf.setupWebView()
                            strongSelf.loadWebview()
                        #endif
                    } else {
                        // 失敗 - 重新啟動ViewController
                        strongSelf.removeBackgroundView()
                        strongSelf.showPartialUpdateErrorAlert(errShowMsg: errShowMsg)
                    }
                }
            }
            ```

            ```Swift
            public func resetOriginalVersion(partialUpdateResetFinishCompletionHandler: @escaping PartialUpdateResetFinish) {
                self.partialUpdateResetFinishCompletionHandler = partialUpdateResetFinishCompletionHandler
                    partialUpdateStep = .RESET

                    updateManager?.clearData()
        
                    updateManager?.revertToOriginalVersion()
            }
            ```
        - `updateWebFile` interfce 呼叫時，呼叫方法下載網頁並進行置換 (未使用)
            ```Swift
            public func updateWeb(url: URL, signature: String, zipCode: String, updateUpdateResultCompletionHandler: @escaping PartialUpdateUpdateResult) {
                self.updateUpdateResultCompletionHandler = updateUpdateResultCompletionHandler
                partialUpdateStep = .UPDATE
                updateManager?.update(with: url, signature: signature, zipCode: zipCode)
            }
            ```
        - 上述方法執行後返回結果
            - 成功: 返回網頁路徑
            - 失敗: 返回錯誤代碼，代碼為`4`會走成功路徑
            ```Swift
            extension PartialUpdateManager: PartialUpdateDelegate {
                func partialUpdateInitFinish() {
                    switch partialUpdateStep {
                        case .INIT:
                            partialUpdateInitFinishCompletionHandler?(true, updateManager?.webFolderPath, updateManager?.htmlName, nil, nil)
                        case .RESET:
                            partialUpdateResetFinishCompletionHandler?(true, updateManager?.webFolderPath, updateManager?.htmlName, nil, nil)
                        case .UPDATE:
                            updateUpdateResultCompletionHandler?(true, updateManager?.webFolderPath, updateManager?.htmlName, nil, nil)
                    }
                }
    
                func partialUpdateFailWithError(_ error: Error?) {
                    let nsError = error as NSError?
                    
                    LogUtil.printLog("\(partialUpdateStep.rawValue) => errCode: \(String(describing: nsError?.code)) errShowMsg => \(String(describing: nsError?.domain))")
                    
                    guard let partialUpdateError = PartialUpdateError(rawValue: nsError?.code ?? -99) else {
                        return
                    }
                            
                    switch partialUpdateStep {
                    case .INIT:
                        partialUpdateInitFinishCompletionHandler?(false, updateManager?.webFolderPath, updateManager?.htmlName, partialUpdateError.rawValue, partialUpdateError.showMsg )
                    case .RESET:
                        partialUpdateResetFinishCompletionHandler?(false, updateManager?.webFolderPath, updateManager?.htmlName, partialUpdateError.rawValue, partialUpdateError.showMsg )
                    case .UPDATE:
                        updateUpdateResultCompletionHandler?(false, updateManager?.webFolderPath, updateManager?.htmlName, partialUpdateError.rawValue, partialUpdateError.showMsg)
                    }
                }
                .
                .
            }
            ```


## 原生頁面
- 首頁
    - 開啟後:
        1. UI
        2. 熱更新
        3. 顯示Alert用於給網頁載入連線端(DEV)
        4. Webview 設定
        5. 載入 Webview
    - 參數 urlIndex 用於網頁導頁
        - 空值載入網頁首頁
        - 提供`推播`、`widget`、`cross app (schema = m)` 進行呼叫
        - 連接`web host(Debug)無導頁功能`
    - `getUserAgentWebView` 提供給iOS12取Useragent
    - 參數 `hybridManager` (HybridSDK)
        - 介紹請看套件部分
        - 有關加密邏輯的interface請看txt檔
    - `devHostUrl` DEV Alert 輸入的網址使用這個紀錄
- 內嵌webview
    - 透過interface(`openWeb`) type 為 `Frame`時呼叫
    - 有開啟 get、post
    - 有判斷自簽憑證錯誤 
- 教學卡片
    - 透過interface(`showTutorial`) 呼叫
    - 此頁面有旁白功能
    - 有多國語系
- widget
    - 若拉autoLayout至vc容易導致容量過大顯示白畫面
- NotificationService
    - 用於顯示推播圖片
## 回覆issue
- Redmine: https://ibts.mitake.com.tw/projects/mtk-ibs-201806250031/issues
- FACE ID
    - FACE ID權限由FIDO套件詢問，由廠商釐清
- 開啟閃退
    - https://ibts.mitake.com.tw/issues/8028
    - 發生在FIDO和行為軌跡套件中，因此請套件廠商釐清

## 備註
1. 驗憑證 (都使用Alamofire)(目前未使用)
    - onVerifyCertificate 定點驗憑證
    - onSendWebApi 憑證綁定
2. 測試帳號
    - A191343486
    - a12345
    - b12345
